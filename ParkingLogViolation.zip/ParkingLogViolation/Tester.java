package ParkingLogViolation;
import javax.swing.*;
public class Tester extends JFrame
{
	public static void main(String[] args)
	{
		PersonView pview = new PersonView();
		View v = new View();
		Model m = new Model(v);
		CarView cview = new CarView();
		Controller c = new Controller(m, v, pview, cview);
	}
}
