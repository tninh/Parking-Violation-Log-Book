package ParkingLogViolation;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JOptionPane;



public class Controller 
{
	PersonView pview;
	Model model;
	View view;
	CarView cview;
	DeletePersonView deview;
	public Controller(Model model, View view, PersonView pview, CarView cview)
	{
		this.model = model;
		this.view = view;
		this.pview = pview;
		this.cview = cview;
		this.deview = deview;
		view.addNameSearchListener(new NameSearchEL());
		view.addPcnSearchListener(new PcnSearchEL());
		view.addDLicenseSearchListener(new DLicenseSearchEL());
		view.insertPersonListener(new AddPersonEL());
		view.insertCarListener(new AddCarEL());
		pview.addSubmitListener(new SubmitEL());
		cview.addSubmitListener(new SubmitC());
	}
	
	class SubmitC implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			String lp = cview.licensePlate.getText();
			String dl = cview.driverLicense.getText();
			int year = Integer.parseInt(cview.year.getText());
			String make = cview.make.getText();
			String cmodel = cview.model.getText();
			String color = cview.color.getText();
			model.addCar(lp, dl, year, make, cmodel, color);
		}
	}
	class SubmitEL implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e) {
			String dl = pview.driverLicense.getText();
			String name = pview.name.getText();
			String dob = pview.dob.getText();
			DateFormat formatter = new SimpleDateFormat("YYYY-MM-DD");
			try {
				Date date = (Date)formatter.parse(dob);
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			String gender = new String();
			if(pview.male.isSelected()) gender = "M";
			if(pview.female.isSelected()) gender = "F";
			model.addUser(dl, name, gender, dob);
			model.TableModel.fireTableDataChanged();
			view.scrollPane.repaint();
		}
	}
	
	class AddCarEL implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			cview.setLocationRelativeTo(null);
			cview.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			cview.setSize(500, 300);
			cview.setVisible(true);
		}
		
	}
	class AddPersonEL implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e) 
		{

			pview.setLocationRelativeTo(null);
			pview.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			pview.setSize(500, 300);
			pview.setVisible(true);
			
			
			
			//JOptionPane.showMessageDialog(null, "Insert Successfully", "Result", JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	
	
	class NameSearchEL implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e)
		{
			// TODO Auto-generated method stub
			String searchParam = view.SearchField.getText();
			searchParam.toUpperCase();
			searchParam.trim();
			model.TableModel=model.search(searchParam, "person", "*", "name", model.TableModel);
			if(searchParam.equals(""))
				JOptionPane.showMessageDialog(null, "Name field CAN'T be empty!", "Error", JOptionPane.ERROR_MESSAGE);
			else if(model.TableModel.getRowCount() == 0)
				JOptionPane.showMessageDialog(null, "No Record", "Result", JOptionPane.INFORMATION_MESSAGE);
			else
			{
				int rowCount = model.TableModel.getRowCount();
				String message = rowCount + " Record found";
				JOptionPane.showMessageDialog(null,message , "Result", JOptionPane.INFORMATION_MESSAGE);
			}
			view.setTable(model.TableModel);
			model.TableModel.fireTableDataChanged();
			view.scrollPane.repaint();
		}
	}
	
	class PcnSearchEL implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String pcn = view.SearchField.getText();
			pcn.toUpperCase();
			
			String query = "select pcn, name, dl, fine from violation inner join car on"
					+ " lplate = lp inner join person on"
					+ " dlicense = dl where pcn = '"+pcn+"' ";
			model.TableModel = model.SearchByQuery(query);
			if(pcn.length() != 10){
				JOptionPane.showMessageDialog(null, "Wrong Pcn number", "Error", JOptionPane.ERROR_MESSAGE);
			}
			else if(model.TableModel.getRowCount() == 0)
			{
				JOptionPane.showMessageDialog(null, "No Record", "Result", JOptionPane.INFORMATION_MESSAGE);
			}
			else
			{
				int rowCount = model.TableModel.getRowCount();
				String message = rowCount + " Record found";
				JOptionPane.showMessageDialog(null,message , "Result", JOptionPane.INFORMATION_MESSAGE);
			}
			view.setTable(model.TableModel);
			model.TableModel.fireTableDataChanged();
			//view.scrollPane.repaint();
		}
	}
	
	class DLicenseSearchEL implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e) {
			String DLicense = view.SearchField.getText();
			DLicense.toUpperCase();
			
			String query = "select dl, name, lp, location, issued, fine from person, car, violation where dl=dlicense and "
					+ " lp=lplate and dl = '"+DLicense+"' ";
			model.TableModel = model.SearchByQuery(query);
			if(DLicense.equals(""))
				JOptionPane.showMessageDialog(null, "Invalid Driver License", "Error", JOptionPane.ERROR_MESSAGE);
			else if(model.TableModel.getRowCount() == 0)
			{
				JOptionPane.showMessageDialog(null, "No Record", "Result", JOptionPane.INFORMATION_MESSAGE);
			}
			else
			{
				int rowCount = model.TableModel.getRowCount();
				String message = rowCount + " Record found";
				JOptionPane.showMessageDialog(null,message , "Result", JOptionPane.INFORMATION_MESSAGE);
			}
				
			view.setTable(model.TableModel);
			model.TableModel.fireTableDataChanged();
		}
	}
	
	
}
